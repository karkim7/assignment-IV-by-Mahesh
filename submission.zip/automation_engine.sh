#!/bin/bash

# Function to organize files (Stage 1)
organize_files() {
    read -p "Enter directory to organize (leave blank for current dir): " dir
    ./organize_files.sh "$dir"
}

# Function to analyze logs (Stage 2)
analyze_logs() {
    read -p "Enter logfile path (default: test_files/access.log): " logfile
    ./analyze_logs.sh "$logfile"
}

# Function to show disk usage
show_disk_usage() {
    echo -e "\n💽 Disk Usage:"
    df -h | awk '{print $1 "\t" $5 "\t" $6}' | column -t
}

# Main menu
while true; do
    clear
    echo "╔══════════════════════════════╗"
    echo "║    FILE MANAGEMENT MENU      ║"
    echo "╠══════════════════════════════╣"
    echo "║ 1. Organize files by type    ║"
    echo "║ 2. Analyze log files         ║"
    echo "║ 3. Check disk usage          ║"
    echo "║ 4. Exit                      ║"
    echo "╚══════════════════════════════╝"
    read -p "Choose an option (1-4): " choice

    case $choice in
        1) organize_files ;;
        2) analyze_logs ;;
        3) show_disk_usage ;;
        4) echo "Exiting..."; exit 0 ;;
        *) echo "❌ Invalid option. Try again." ;;
    esac
    read -p "Press [Enter] to continue..."
done
