Week 4 Assignment by Mahesh Karki, 1063667

# CS 450 Mini Project: File Management Automation Engine  
**Instructor**: Dr. Murchtricia Jones  
**Semester**: Summer 2025  
**University**: Carolina University, Winston-Salem  

---

##  Project Description  
A **menu-driven shell script** that automates file management tasks in Unix, including:  
- Organizing files by type (e.g., `.txt`, `.log`).  
- Analyzing log files for errors/warnings.  
- Monitoring system disk usage.  

---

##  Features  
| Feature                | Command Used           | Description                          |  
|------------------------|------------------------|--------------------------------------|  
| File Organizer         | `find`, `mv`, `mkdir`  | Sorts files into `Text/`, `Logs/`, etc. |  
| Log Analyzer           | `grep`, `wc`, `tail`   | Counts errors/warnings and shows recent activity. |  
| Disk Usage Reporter    | `df`, `awk`, `column`  | Displays storage metrics in a clean table. |  

---

##  Installation & Usage  
### Dependencies  
- Bash (`v4.0+`)  
- Core Unix utilities: `find`, `grep`, `awk`, `df`  

### Steps to Run  
1. Clone the project:  
   ```bash  
    
   cd cs450-mini-project  





   #

   Then, run this command in your wsl i.e bash

./automation_engine.sh  

[Note: Now, You shoud be able to get output as expected]